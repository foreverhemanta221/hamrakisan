<?php
namespace App\Http\Controllers\Frontend;
use App\CartItem;
use App\Http\Controllers\Controller;
use App\Models\FarmProduct;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;
class OrderController extends Controller
{
    public function addToCart(Request $request){
       if(Auth::check()==true){
           if(Auth::user()->role=='user' || Auth::user()->role=='farmer'){
               foreach($request->productId as $key=>$value){
                   $oldcartitem = Session::has('cartitem') ? Session::get('cartitem') :null;
                   $product = FarmProduct::find($value);
                   $cartitem = new CartItem($oldcartitem);
                   $cartitem->add($product,$product->id,(int)$request->productQty[$key]);
                   $request->session()->put('cartitem',$cartitem);
               }
        return response()->json(['message'=>'Item Added Successfully','status'=>true],200);
           }
       }
        return response()->json(['message'=>'Login is Required','status'=>false],200);
    }
    public function updateCart(Request $request){
        $productId = $request->productId;
        $productQty = $request->productQty;
        $product = FarmProduct::find($productId);
        $oldcartitem = Session::has('cartitem') ? Session::get('cartitem') :null;
        $cartItem = new CartItem($oldcartitem);
        $cartItem->update($product,$productId,$productQty);
        $request->session()->put('cartitem',$cartItem);
        return response()->json(['message'=>'Item Added Successfully','status'=>true],200);
    }
    public function myCart(Request $request){


        if(!Session::has('cartitem')){
            return view('frontend.cart');
        }else{
            $tempFarmId = 0;
            $newkey=0;
            $grouparr[$tempFarmId]="";
            $originalArray = Session::get('cartitem');
            foreach ($originalArray->items as $key=>$value) {
                if ($tempFarmId==$value['farmId']){
                    $grouparr[$tempFarmId][$newkey]=$value;
                }else{
                    $grouparr[$value['farmId']][$newkey]=$value;
                }
                $newkey++;
            }
            return view('frontend.cart')->with('groupArr',$grouparr);
        }
    }
    public function checkout(){
        $cart = Session::get('cartitem');
        $amount = 0;
        if($cart!=nuLL){
            foreach($cart->items as $items){
                $amount+=$items['productPrice'];
            }
        }
        return view('frontend.checkout')->withAmount($amount);
    }
    public function order(Request $request){
        if(Auth::check()==true){

            $items = collect();
            $items->push(session()->get('cartitem'));
            dd($items[0]->items->groupBy('farmId'));

//            $cart = Session::get('cartitem');


//            if($cart!=nuLL){
//                foreach($cart->items as $items){
//                    //add in order table
//
//                }
//            }
        }
    }
}
